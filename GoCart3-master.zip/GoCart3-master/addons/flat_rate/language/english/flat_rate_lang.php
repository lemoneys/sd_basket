<?php

$lang['flat_rate'] = 'Flat Rate';
$lang['enabled'] = 'Enabled';
$lang['disabled'] = 'Disabled';
$lang['rate'] = 'Rate';