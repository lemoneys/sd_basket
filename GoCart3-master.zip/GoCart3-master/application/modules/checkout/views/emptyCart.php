<div class="alert"><?php echo lang('empty_view_cart');?></div>

<div class="text-center">
    <a href="<?php echo site_url();?>" class="btn btn-primary blue"><?php echo lang('continue_shopping');?></a>
</div>
