<?php
$routes[] = ['GET|POST', '/my-account', 'GoCart\Controller\MyAccount#index'];
$routes[] = ['GET|POST', '/my-account/downloads', 'GoCart\Controller\MyAccount#downloads'];