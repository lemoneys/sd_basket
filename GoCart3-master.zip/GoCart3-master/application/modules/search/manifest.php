<?php
$routes[] = ['GET|POST', '/search/[:code]?/[:sort]?/[:dir]?/[:page]?', 'GoCart\Controller\Search#index'];