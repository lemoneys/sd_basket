<?php

$routes[] = ['GET', '/admin/dashboard', 'GoCart\Controller\AdminDashboard#index'];
$routes[] = ['GET', '/admin', 'GoCart\Controller\AdminDashboard#index'];
