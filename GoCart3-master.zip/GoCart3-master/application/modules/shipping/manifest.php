<?php

$routes[] = ['GET|POST', '/admin/shipping', 'GoCart\Controller\AdminShipping#index'];